Duck with Potato (Assmaese Style)

Ingredients
* 1/2 kg of duck meat, cleaned and washed.
* 6 tbsp mustard oil
* 2 tbsp garlic paste
* 2 tbsp ginger paste
* 2 tbsp cumin and black pepper paste (in 1:1 ratio)
* 1/2 tbsp turmeric powder
* 4 chopped onions
* 4 green chillies
* 4 dry red chillies
* 3 potatoes
* 2 bay leaves

Procedure
1. In a bowl, marinate the duck with garlic and ginger paste, turmeric powder, cumin and black pepper paste, along with a tablespoon of mustard oil.
2. Peel and cut the potatoes into chunks.
3. Heat remaining oil in kadhai. Add bay leaves, green and dry red chillies.
4. Toss in the chopped onions and fry until golden brown.
5. Put in the marinated duck and continue frying for a few minutes.
6. Throw in the potaotes and keep frying. After a few minute, add one cup of water.
7. Cover and cook on medium heat, stirrring from time to time, until the duck is tender.
8. Remove from fire and serve hot with steamed rice.